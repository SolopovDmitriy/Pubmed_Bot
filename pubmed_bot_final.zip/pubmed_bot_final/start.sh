#!/bin/bash
python3 pubmed_bot.py

